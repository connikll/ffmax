import sqlite3
import configparser
import os
import re
import sys
from datetime import datetime
import argparse
from tqdm import tqdm
import time

class LogAnalyzer:
    def __init__(self):
        # Инициализация конфигурационного файла и подключение к базе данных
        self.config = configparser.ConfigParser()
        self.load_config()
        self.db_path = self.config['Database']['URI'].replace('sqlite:///', '')
        self.init_db()

    def load_config(self):
        """ Загружаем настройки конфигурации либо создаем новый файл config.ini Если файл отсутствует — создаём базовую структуру настроек. """
        self.config.read('config.ini')
        
        if not self.config.sections():
            self.config['Database'] = {'URI': 'sqlite:///logs.db'}  # Путь к SQLite файлу
            self.config['Logs'] = {'Directory': 'logs', 'Pattern': 'access.log'}  # Директория и шаблон имени лог-файла
            with open('config.ini', 'w') as f:
                self.config.write(f)

    def init_db(self):
        """ Создает базу данных SQLite, если её ещё нет, и создает таблицу для хранения логов. """
        if os.path.dirname(self.db_path):  # Проверяем наличие родительской директории
            os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
            
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(''' CREATE TABLE IF NOT EXISTS log_entries ( id INTEGER PRIMARY KEY AUTOINCREMENT, ip TEXT, date TEXT, method TEXT, url TEXT, status INTEGER, size INTEGER, user_agent TEXT ) ''')
        conn.commit()
        conn.close()

    def parse_log_file(self):
        """ Парсим содержимое лог-файла и сохраняем записи в базу данных. Используем progress bar для визуализации процесса обработки большого объёма данных. """
        log_path = os.path.join(
            self.config['Logs']['Directory'],  # Читаем путь к директорию логов
            self.config['Logs']['Pattern']     # Название шаблона лог-файла
        )
        
        if not os.path.exists(log_path):
            print(f"Ошибка: Не удалось найти файл логов: {log_path}")
            return False

        with open(log_path, 'r', encoding='utf-8') as f:
            total_lines = sum(1 for _ in f)  # Подсчет общего числа строк в файле

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        parsed_count = 0

        print(f"\nНачало обработки файла: {log_path}\n")
        with tqdm(total=total_lines, desc="Прогресс", unit="стр.") as pbar:
            with open(log_path, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        parsed = self.parse_line(line.strip())  # Анализируем каждую строку
                        if parsed:
                            cursor.execute(''' INSERT INTO log_entries (ip, date, method, url, status, size, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?) ''', parsed)
                            parsed_count += 1
                    except Exception as e:
                        print(f"\nОшибка разбора строки: {e}", file=sys.stderr)
                    finally:
                        pbar.update(1)
                        time.sleep(0.001)  # Небольшая задержка для плавности прогресса

        conn.commit()  # Сохраняем изменения в базе данных
        conn.close()
        print(f"\nЗавершили обработку. Всего обработано строк: {parsed_count}/{total_lines}")
        return True

    def parse_line(self, line):
        """ Извлекает необходимую информацию из каждой строки лога Apache. Возвращает кортеж с нужными полями или None, если произошла ошибка анализа. """
        match = re.match(r'^(\S+) \S+ \S+ $$(.*?)$$ "(.*?)" (\d+) (\d+) "(.*?)" "(.*?)"', line)
        if not match:
            return None

        ip, date_str, request, status_code, response_size, _, user_agent = match.groups()
        method, url, _ = request.split(' ', 2)
        
        try:
            date = datetime.strptime(date_str, '%d/%b/%Y:%H:%M:%S %z').isoformat()
        except ValueError:
            date = date_str

        return (
            ip,
            date,
            method,
            url,
            int(status_code),
            int(response_size),
            user_agent if user_agent != '-' else None
        )

    def show_logs(self, filters):
        """ Отображает логи из базы данных с возможностью фильтрации по различным параметрам. Поддерживает фильтры по IP, ключевым словам в URL, диапазону дат и ограничению вывода. """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        conditions = []  # Список условий SQL для фильтров
        values = []      # Параметры, подставляемые в условия WHERE

        if filters.get('ip'):          # Фильтрация по IP
            conditions.append("ip = ?")
            values.append(filters['ip'])
        if filters.get('keyword'):     # Фильтрация по ключу в URL
            conditions.append("url LIKE ?")
            values.append(f"%{filters['keyword']}%")
        if filters.get('date_from'):   # Минимальная дата события
            conditions.append("date >= ?")
            values.append(filters['date_from'])
        if filters.get('date_to'):     # Максимальная дата события
            conditions.append("date <= ?")
            values.append(filters['date_to'])

        sql_conditions = "AND ".join(conditions) if conditions else ""  # Формируем условие WHERE
        limit_clause = f"LIMIT {filters.get('limit', 100)}"              # Устанавливаем ограничение записей

        query = f"SELECT * FROM log_entries WHERE {sql_conditions} ORDER BY date DESC {limit_clause}" \
               if sql_conditions else f"SELECT * FROM log_entries ORDER BY date DESC {limit_clause}"
        
        cursor.execute(query, tuple(values))
        results = cursor.fetchall()

        if not results:
            print("Записи не найдены.")
            return

        print("\nПолученные результаты:\n")
        print("-" * 120)
        print(f"| {'IP':<15} | {'Дата':<20} | {'Метод':<6} | {'URL':<40} | {'Код':<6} | {'Размер':<6} |")
        print("-" * 120)
        
        for row in results:
            print(f"| {row[1]:<15} | {row[2][:19]:<20} | {row[3]:<6} | {row[4][:40]:<40} | {row[5]:<6} | {row[6]:<6} |")
        
        print("-" * 120)
        print(f"Количество результатов: {len(results)}\n")
        conn.close()

def main():
    """ Основной метод программы. Организует работу с интерфейсом командной строки и запуск выбранных действий. """
    parser = argparse.ArgumentParser(description='Анализатор логов Apache')
    
    # Добавляем подпараметры командной строки
    subparsers = parser.add_subparsers(dest='command', required=True)

    # Команда парсинга логов
    parse_parser = subparsers.add_parser('parse', help='Выполнить разбор лог-файла')

    # Команда просмотра логов
    show_parser = subparsers.add_parser('show', help='Показать логи')
    show_parser.add_argument('--ip', help='Выбрать логи по указанному IP')
    show_parser.add_argument('--keyword', help='Поиск по части URL')
    show_parser.add_argument('--date-from', help='Начальная дата (формат: ГГГГ-ММ-ДД)')
    show_parser.add_argument('--date-to', help='Конечная дата (формат: ГГГГ-ММ-ДД)')
    show_parser.add_argument('--limit', type=int, default=100, help='Ограничение кол-ва записей')

    args = parser.parse_args()
    analyzer = LogAnalyzer()

    if args.command == 'parse':
        analyzer.parse_log_file()
    elif args.command == 'show':
        analyzer.show_logs({
            'ip': args.ip,
            'keyword': args.keyword,
            'date_from': args.date_from,
            'date_to': args.date_to,
            'limit': args.limit
        })

if __name__ == '__main__':
    main()